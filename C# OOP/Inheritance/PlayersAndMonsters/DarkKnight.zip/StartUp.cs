﻿namespace PlayersAndMonsters
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Hero wiz = new Knight("Gosho", 12);

            System.Console.WriteLine(wiz);
        }
    }
}